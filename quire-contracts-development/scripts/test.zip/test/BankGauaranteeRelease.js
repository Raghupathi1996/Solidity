const fs = require('fs')
const HDWalletProvider = require('@truffle/hdwallet-provider');


const BankGuaranteeReleaseManager = artifacts.require('BankGuaranteeReleaseManager');



const editData = (newData) => {
    path = './scripts/test/data.json';
    if(fs.existsSync(path)) {fs.unlinkSync(path)}
    fs.writeFileSync(path, JSON.stringify(newData));
    return newData;
}

module.exports = async function (callback) {
    
    const data = JSON.parse(fs.readFileSync('./scripts/test/data.json'));

    const provider = new HDWalletProvider({
      privateKeys: [data.keys.admin.privateKey, data.keys.egp.privateKey, data.keys.vendor1.privateKey, data.keys.vendor2.privateKey, data.keys.bank1.privateKey,  data.keys.bank2.privateKey],
      providerOrUrl: "http://127.0.0.1:22000/",
      chainId: 10
    });

    BankGuaranteeReleaseManager.setProvider(provider);

    let bgRelease = await BankGuaranteeReleaseManager.deployed();

    console.log("start");

    let bgRelease1bank1pa1V1 = 
    await bgRelease.publishBankGuaranteeRelease({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA03",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "test_branchName",
        "releaseDate": 2345, 
        "currency": "INR", 
        "amountReleased": 100, 
        "bgReleaseFileHash": "23454931", 
        version:1}, {from: data.keys.egp.address}
    );

    console.log(bgRelease1bank1pa1V1);
    console.log(bgRelease1bank1pa1V1.logs[0]);
    // bgRelease1bank1pa1V1 = bgRelease1bank1pa1V1.logs[0].args._bgReleaseUid;
    // data.uids.bgRelease1bank1pa1V1 = bgRelease1bank1pa1V1;
    // editData(data);

    // publishBankGuaranteeInvoke
    let bgInvoke1bank1pa1V1 = 
    await bgRelease.publishBankGuaranteeInvoke({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA03",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "test_branchName",
        "revocationDate": 2345, 
        "currency": "INR", 
        "revocationAmount": 200,
        "beneficiaryName": "Raghupathi",
        "beneficiaryBankAccountNumber": "12345467890",
        "beneficiaryBankName":"SBI",
        "beneficiaryBranchName":"Akshaya",
        "beneficiaryIfscCode":"ABC",
        "bgInvokeFileHash": "23454931", 
        version:1}, {from: data.keys.egp.address}
    );

    console.log(bgInvoke1bank1pa1V1);
    console.log(bgInvoke1bank1pa1V1.logs[0]);
    // bgInvoke1bank1pa1V1 = bgInvoke1bank1pa1V1.logs[0].args._bgReleaseUid;
    // data.uids.bgInvoke1bank1pa1V1 = bgInvoke1bank1pa1V1;

    let bgRelease2bank1pa1V1 = 
    await bgRelease.publishBankGuaranteeRelease({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA03",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "test_branchName",
        "releaseDate": 2345, 
        "currency": "INR", 
        "amountReleased": 300, 
        "bgReleaseFileHash": "23454931", 
        version:1}, {from: data.keys.egp.address}
    );

    console.log(bgRelease2bank1pa1V1);
    console.log(bgRelease2bank1pa1V1.logs[0]);

    let bgInvoke2bank1pa1V1 = 
    await bgRelease.publishBankGuaranteeInvoke({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA03",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "test_branchName",
        "revocationDate": 2345, 
        "currency": "INR", 
        "revocationAmount": 400,
        "beneficiaryName": "Raghupathi",
        "beneficiaryBankAccountNumber": "12345467890",
        "beneficiaryBankName":"SBI",
        "beneficiaryBranchName":"Akshaya",
        "beneficiaryIfscCode":"ABC",
        "bgInvokeFileHash": "23454931", 
        version:1}, {from: data.keys.egp.address}
    );

    console.log(bgInvoke2bank1pa1V1);
    console.log(bgInvoke2bank1pa1V1.logs[0]);

    let bgInvoke3bank1pa1V1 = 
    await bgRelease.publishBankGuaranteeInvoke({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA03",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "test_branchName",
        "revocationDate": 2345, 
        "currency": "INR", 
        "revocationAmount": 500,
        "beneficiaryName": "Raghupathi",
        "beneficiaryBankAccountNumber": "12345467890",
        "beneficiaryBankName":"SBI",
        "beneficiaryBranchName":"Akshaya",
        "beneficiaryIfscCode":"ABC",
        "bgInvokeFileHash": "23454931", 
        version:1}, {from: data.keys.egp.address}
    );

    console.log(bgInvoke3bank1pa1V1);
    console.log(bgInvoke3bank1pa1V1.logs[0]);

    callback();
};
// gitignore test

