const fs = require('fs')
const HDWalletProvider = require('@truffle/hdwallet-provider');


const BankGuaranteeReleaseManager = artifacts.require('BankGuaranteeReleaseManager');



const editData = (newData) => {
    path = './scripts/test/data.json';
    if(fs.existsSync(path)) {fs.unlinkSync(path)}
    fs.writeFileSync(path, JSON.stringify(newData));
    return newData;
}

module.exports = async function (callback) {
    
    const data = JSON.parse(fs.readFileSync('./scripts/test/data.json'));

    const provider = new HDWalletProvider({
      privateKeys: [data.keys.admin.privateKey, data.keys.egp.privateKey, data.keys.vendor1.privateKey, data.keys.vendor2.privateKey, data.keys.bank1.privateKey,  data.keys.bank2.privateKey],
      providerOrUrl: "http://127.0.0.1:22000/",
      chainId: 10
    });

    BankGuaranteeReleaseManager.setProvider(provider);

    let bgRelease = await BankGuaranteeReleaseManager.deployed();

    console.log("start");

    let bgRelease1bank1pa1V1 = await bgRelease.getBgReleasesAndInvokesListByPaBankGid("PA03",data.gids.bank1Gid, 20, 20);

    console.log(bgRelease1bank1pa1V1);
    // console.log(JSON.stringify(bgRelease1bank1pa1V1));
    console.log(bgRelease1bank1pa1V1.logs[0]);
    // bgRelease1bank1pa1V1 = bgRelease1bank1pa1V1.logs[0].args._bgReleaseUid;
    // data.uids.bgRelease1bank1pa1V1 = bgRelease1bank1pa1V1;
    // editData(data);

    callback();
};
// gitignore test

