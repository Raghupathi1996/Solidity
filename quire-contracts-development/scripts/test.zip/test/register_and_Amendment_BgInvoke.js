const fs = require('fs')
const HDWalletProvider = require('@truffle/hdwallet-provider');

const BankGuaranteeReleaseManager = artifacts.require('BankGuaranteeReleaseManager');

const editData = (newData) => {
    path = './scripts/test/data.json';
    if(fs.existsSync(path)) {fs.unlinkSync(path)}
    fs.writeFileSync(path, JSON.stringify(newData));
    return newData;
}

module.exports = async function (callback) {
    
    const data = JSON.parse(fs.readFileSync('./scripts/test/data.json'));

    const provider = new HDWalletProvider({
      privateKeys: [data.keys.admin.privateKey, data.keys.egp.privateKey, data.keys.vendor1.privateKey, data.keys.vendor2.privateKey, data.keys.bank1.privateKey,  data.keys.bank2.privateKey],
      providerOrUrl: "http://127.0.0.1:22000/",
      chainId: 10
    });

    BankGuaranteeReleaseManager.setProvider(provider);


    let bgRelease = await BankGuaranteeReleaseManager.deployed();

    console.log("start");

    let bgR1bank1pa1V1 = await bgRelease.publishBankGuaranteeInvoke({
        "uid":"0x00000000", 
        "bankGuaranteeUid": data.uids.bg1bank1pa1V1,
        "paymentReference": "PA01",
        "procuringEntityGid": data.gids.peGid,
        "egpSystemId":`ADMINORG.${data.egp}`,
        "vendorGid": data.gids.ven1Gid, 
        "bankGid":data.gids.bank1Gid, 
        "branchName": "1662814931",
        "revocationDate": 10, 
        "currency":"INR",
        "revocationAmount": 03, 
        "beneficiaryName": "1662814931", 
        "beneficiaryBankAccountNumber": "1662814931", 
        "beneficiaryBankName":"INR", 
        "beneficiaryBranchName": "as",
        "beneficiaryIfscCode": "test_fileHash", 
        "bgInvokeFileHash":"dsc",
        version:1}, {from: data.keys.egp.address}) .then(
            receipt => { console.log(receipt);}) .catch (error => {console.log(error);})

    console.log(bgR1bank1pa1V1);
    // console.log(bgR1bank1pa1V1.logs[0]);
    // bgR1bank1pa1V1 = bgR1bank1pa1V1.logs[0].args._bgUid;
    // data.uids.bgR1bank1pa1V1 = bgR1bank1pa1V1;
    // editData(data);

// await bankGuaranteeReleaseManager.publishBankGuaranteeInvoke({uid:'0x00000000',bankGuaranteeUid:'0xf69d7d74d43b8a1d',paymentReference:'test_paymecdccddnt_reference',procuringEntityGid:'6FNPS45A',egpSystemId:'ADMINORG.EGP_a8af',vendorGid:'1UVKHLI9',bankGid:'MMNR83HM',branchName:'',revocationDate:255,revocationAmount:1,beneficiaryName:"",beneficiaryBankAccountNumber:"",beneficiaryBankName:"",beneficiaryBranchName:"",beneficiaryIfscCode:"",bgInvokeFileHash:'ccddcscds',version:''})

    callback();
};
// gitignore test

